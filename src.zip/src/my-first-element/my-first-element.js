import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';

/**
 * @customElement
 * @polymer
 */
class MyFirstElement extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
      <h2>POLYMER Operation</h2>
      <table>
          <tr>
            <td>Id</td>
            <td><input type="text" name="Id" value={{id::input}}></td>
          </tr>
          <tr>
            <td>Name</td>
            <td><input type="text" name="Name" value={{name::input}} ></td>
          </tr>
          <tr>
            <td>Department</td>
            <td><input type="text" name="Department" value= {{department::input}}></td>
          </tr>
          <tr>
            <td>Salary</td>
            <td><input type="text" name="Salary" value={{salary::input}} ></td>
          </tr>
          <tr>
            <td colspan=2><input type="button" value="Add Employee" on-click="showEmployeeDetails"></td>
          </tr>
          <tr>
            <td colspan=2>[[id]] [[name]] [[department]] [[salary]]</td>
          </tr>
      </table>
    `;
  }
  static get properties() {
    return {
      id: {
        type: String,
        value: ''
      },
      name: {
        type: String,
        value: ''
      },
      department: {
        type: String,
        value: ''
      },
      salary: {
        type: String,
        value: ''
      }
    };
  }
  showEmployeeDetails(){
    alert(this.id+this.name+this.department+this.salary)
  }
}

window.customElements.define('my-first-element', MyFirstElement);
